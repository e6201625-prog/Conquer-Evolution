extends Node2D

# Small single-player mobile prototype. Touch controls are drawn in-game.
const WORLD_SIZE = Vector2(1500, 1050)
const PLAYER_SPEED = 235.0
const JOY_CENTER = Vector2(112, 425)
const JOY_RADIUS = 65.0
const ATTACK_RECT = Rect2(790, 385, 145, 115)

var player_pos = Vector2(750, 525)
var enemies = []
var hp = 100
var mp = 40
var level = 1
var exp = 0
var attack_flash = 0.0
var joystick_id = -1
var joystick_vec = Vector2.ZERO
var attack_pressed = false
var message = "اهزم الوحوش واجمع الخبرة!"
var message_timer = 4.0
var camera_offset = Vector2.ZERO
var font = null

func _ready():
    set_process(true)
    enemies = [
        {"pos": Vector2(560, 420), "hp": 2, "alive": true, "phase": 0.0},
        {"pos": Vector2(930, 460), "hp": 2, "alive": true, "phase": 1.0},
        {"pos": Vector2(680, 700), "hp": 2, "alive": true, "phase": 2.0},
        {"pos": Vector2(1080, 650), "hp": 2, "alive": true, "phase": 3.0}
    ]

func _process(delta):
    var move = joystick_vec
    if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
        move.x -= 1
    if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
        move.x += 1
    if Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W):
        move.y -= 1
    if Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S):
        move.y += 1
    if move.length() > 1:
        move = move.normalized()
    player_pos += move * PLAYER_SPEED * delta
    player_pos.x = clamp(player_pos.x, 70, WORLD_SIZE.x - 70)
    player_pos.y = clamp(player_pos.y, 90, WORLD_SIZE.y - 70)

    for e in enemies:
        if e["alive"]:
            e["phase"] += delta
            var toward = player_pos - e["pos"]
            if toward.length() < 240 and toward.length() > 38:
                e["pos"] += toward.normalized() * 48.0 * delta

    if attack_flash > 0:
        attack_flash -= delta
    if message_timer > 0:
        message_timer -= delta
    update()

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.distance_to(JOY_CENTER) < 110:
                joystick_id = event.index
                _update_joystick(event.position)
            elif ATTACK_RECT.has_point(event.position):
                _attack()
        else:
            if event.index == joystick_id:
                joystick_id = -1
                joystick_vec = Vector2.ZERO
    elif event is InputEventScreenDrag:
        if event.index == joystick_id:
            _update_joystick(event.position)
    elif event is InputEventMouseButton and event.pressed:
        if event.position.distance_to(JOY_CENTER) < 110:
            joystick_id = -2
            _update_joystick(event.position)
        elif ATTACK_RECT.has_point(event.position):
            _attack()
    elif event is InputEventMouseMotion and joystick_id == -2 and Input.is_mouse_button_pressed(BUTTON_LEFT):
        _update_joystick(event.position)
    elif event is InputEventMouseButton and not event.pressed and joystick_id == -2:
        joystick_id = -1
        joystick_vec = Vector2.ZERO
    elif event is InputEventKey and event.pressed and event.scancode == KEY_SPACE:
        _attack()

func _update_joystick(pos):
    var offset = pos - JOY_CENTER
    if offset.length() > JOY_RADIUS:
        offset = offset.normalized() * JOY_RADIUS
    joystick_vec = offset / JOY_RADIUS

func _attack():
    attack_flash = 0.22
    var target_index = -1
    var best = 155.0
    for i in range(enemies.size()):
        var e = enemies[i]
        if e["alive"]:
            var d = player_pos.distance_to(e["pos"])
            if d < best:
                best = d
                target_index = i
    if target_index >= 0:
        enemies[target_index]["hp"] -= 1
        if enemies[target_index]["hp"] <= 0:
            enemies[target_index]["alive"] = false
            exp += 25
            message = "أحسنت! حصلت على 25 خبرة"
            message_timer = 2.2
            if exp >= level * 100:
                exp = 0
                level += 1
                hp = 100
                message = "مبروك! وصلت للمستوى " + str(level)
                message_timer = 3.0
    else:
        message = "اقترب من وحش ثم اضغط هجوم"
        message_timer = 1.5

func _draw():
    # Camera follows the player while keeping the viewport inside the small map.
    var view = get_viewport_rect().size
    camera_offset = player_pos - view / 2
    camera_offset.x = clamp(camera_offset.x, 0, WORLD_SIZE.x - view.x)
    camera_offset.y = clamp(camera_offset.y, 0, WORLD_SIZE.y - view.y)

    draw_rect(Rect2(Vector2.ZERO, view), Color(0.12, 0.24, 0.16), true)
    # Isometric-inspired grass tiles.
    var start_x = int(camera_offset.x / 80) * 80
    var start_y = int(camera_offset.y / 48) * 48
    for x in range(start_x, int(camera_offset.x + view.x) + 120, 80):
        for y in range(start_y, int(camera_offset.y + view.y) + 80, 48):
            var p = Vector2(x, y) - camera_offset
            var points = PoolVector2Array([p + Vector2(40,0), p + Vector2(80,24), p + Vector2(40,48), p + Vector2(0,24)])
            var col = Color(0.20, 0.39, 0.23) if ((x / 80 + y / 48) % 2 == 0) else Color(0.17, 0.34, 0.20)
            draw_colored_polygon(points, col)
            draw_polyline(points, Color(0.10, 0.24, 0.14), 1.0, true)

    # Path and decorative trees.
    for i in range(8):
        var tree_world = Vector2(260 + i * 155, 210 + (i % 3) * 235)
        var tp = tree_world - camera_offset
        if Rect2(Vector2(-60,-80), view + Vector2(120,160)).has_point(tp):
            draw_circle(tp + Vector2(0,12), 13, Color(0.25,0.15,0.08))
            draw_circle(tp + Vector2(0,-8), 25, Color(0.08,0.27,0.12))
            draw_circle(tp + Vector2(-9,-18), 14, Color(0.12,0.36,0.16))

    # Enemies.
    for e in enemies:
        if e["alive"]:
            var p = e["pos"] - camera_offset
            draw_circle(p + Vector2(0,13), 17, Color(0.07,0.10,0.08,0.35))
            draw_circle(p, 17, Color(0.67,0.25,0.19))
            draw_circle(p + Vector2(-6,-4), 3, Color(1,1,1))
            draw_circle(p + Vector2(6,-4), 3, Color(1,1,1))
            draw_rect(Rect2(p + Vector2(-19,-29), Vector2(38,5)), Color(0.12,0.08,0.08))
            draw_rect(Rect2(p + Vector2(-19,-29), Vector2(38 * float(e["hp"]) / 2.0,5)), Color(0.85,0.18,0.12))

    # Player: blue tunic, head, sword.
    var pp = player_pos - camera_offset
    draw_circle(pp + Vector2(0,17), 19, Color(0.05,0.08,0.06,0.38))
    draw_colored_polygon(PoolVector2Array([pp+Vector2(-13,0),pp+Vector2(13,0),pp+Vector2(17,25),pp+Vector2(-17,25)]), Color(0.16,0.34,0.75))
    draw_circle(pp + Vector2(0,-10), 12, Color(0.88,0.67,0.48))
    draw_arc(pp + Vector2(0,-10), 12, 3.1, 6.25, 16, Color(0.20,0.13,0.08), 5)
    draw_line(pp + Vector2(11,7), pp + Vector2(29, -13), Color(0.85,0.88,0.94), 4)
    draw_line(pp + Vector2(7,8), pp + Vector2(18,14), Color(0.45,0.25,0.10), 4)
    if attack_flash > 0:
        draw_arc(pp + Vector2(0,0), 52, -1.0, 1.0, 24, Color(1.0,0.92,0.48), 5)

    _draw_hud(view)
    _draw_controls()

func _draw_hud(view):
    draw_rect(Rect2(15, 14, 270, 82), Color(0.04,0.06,0.09,0.88), true)
    _text("CONQUER EVOLUTION", Vector2(27, 35), 16, Color(0.96,0.82,0.42))
    _text("Warrior   Lv. " + str(level), Vector2(27, 55), 14, Color(1,1,1))
    draw_rect(Rect2(27, 64, 170, 9), Color(0.22,0.08,0.08), true)
    draw_rect(Rect2(27, 64, 170 * hp / 100.0, 9), Color(0.83,0.16,0.14), true)
    draw_rect(Rect2(27, 78, 170, 7), Color(0.08,0.12,0.25), true)
    draw_rect(Rect2(27, 78, 170 * float(exp) / max(100, level * 100), 7), Color(0.20,0.55,0.95), true)
    if message_timer > 0:
        draw_rect(Rect2(view.x/2 - 190, 18, 380, 35), Color(0.02,0.03,0.04,0.78), true)
        _text(message, Vector2(view.x/2 - 175, 41), 15, Color(1,0.92,0.68))
    _text("Small training valley", Vector2(view.x - 190, 28), 13, Color(0.9,0.9,0.8))

func _draw_controls():
    draw_circle(JOY_CENTER, JOY_RADIUS, Color(0.02,0.03,0.05,0.42))
    draw_circle(JOY_CENTER, JOY_RADIUS, Color(0.7,0.8,0.9,0.7), false, 3)
    draw_circle(JOY_CENTER + joystick_vec * 34, 25, Color(0.65,0.75,0.9,0.78))
    draw_circle(Vector2(862, 440), 53, Color(0.55,0.10,0.08,0.88))
    draw_circle(Vector2(862, 440), 53, Color(1.0,0.72,0.52), false, 3)
    _text("ATTACK", Vector2(828, 445), 17, Color(1,1,1))
    _text("MOVE", Vector2(85, 515), 12, Color(1,1,1,0.8))

func _text(value, pos, size, color):
    draw_string(get_font("font"), pos, value, color, -1, size)
